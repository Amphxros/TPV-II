#include <iostream>
#include <SDL.h>

#include "sdlutils/sdlutils_demo.h"

int main(int ac, char **av) {

	sdlutils_basic_demo();

	return 0;
}

