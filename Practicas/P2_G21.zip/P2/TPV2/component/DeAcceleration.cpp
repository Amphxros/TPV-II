#include "DeAcceleration.h"
#include "Transform.h"
DeAcceleration::DeAcceleration(double thrust):thrust_(thrust)
{
}

DeAcceleration::~DeAcceleration()
{
}