#include "Generations.h"

Generations::Generations(int gen): gen_(gen)
{
}

Generations::~Generations()
{
}
