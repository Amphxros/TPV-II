#include "Generations.h"

Generations::Generations(int gen):Component(), gen_(gen)
{
}

Generations::~Generations()
{
}
